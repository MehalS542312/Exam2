/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author S542312
 */
public class array2d {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][] m1 = new int[3][3];
        int[][] m2 = new int[3][3];

        Scanner scan = new Scanner(System.in);
        System.out.print("Enter list1: ");
        for (int m = 0; m< m1.length; m++)
            for (int n = 0; n < m1[m].length; n++)
                m1[m][n] = scan.nextInt();
        System.out.print("Enter list2: ");
        for (int m = 0; m < m2.length; m++)
            for (int n = 0; n < m2[m].length; n++)
                m2[m][n] = scan.nextInt();

        if (equals(m1, m2)) {
            System.out.println("The Two arrays are strictly identical");
        } else {
            System.out.println("The Two arrays are not strictly identical");
        }
    }

    public static boolean equals(int[][] m1, int[][] m2) {

        if (m1.length != m2.length || m1[0].length != m2[0].length) return false;

        for (int m = 0; m < m1.length; m++) {
            for (int n = 0; n < m1[m].length; n++) {

                if (m1[m][n] != m2[m][n]) 
                    return false;
            }
        }
        return true;
    }
}