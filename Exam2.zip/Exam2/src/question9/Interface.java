/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S542312
 */
import java.io.*;
  

interface Inter1
{
    // public, static and final
    final int m = 10;
  
    // public and abstract 
    void display();
}
  
// A class that implements the interface.
class TestClass implements Inter1
{
    // Implementing the capabilities of
    // interface.
    @Override
    public void display()
    {
        System.out.println("Interface");
    }
  
    // Driver Code
    public static void main (String[] args)
    {
        TestClass test = new TestClass();
        test.display();
        System.out.println(test);
    }
}
