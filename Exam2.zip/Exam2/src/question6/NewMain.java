import java.io.*;
import java.util.Scanner;

class GeometricObject
{

      void setSide1(double t1)
      {
         side1 = t1;
      }
      void setSide2(double t2)
      {
         side2 = t2;
      }
       void setSide3(double t3)
      {
         side3 = t3;
      }
      double getSide1()
      {
        return (side1);
      }
      double getSide2()
      {
        return (side2);
      }
       double getSide3()
      {
         return (side3);
      }
      void setColor(String clr)
      {
      color=clr;
      }
      String getColor()
      {
      return(color);
      }
      void setFilled(boolean fill)
      {
      filled=fill;
      }
      boolean isFilled()
      {
      return(filled);
      }

      double side1,side2,side3;
      String color;
      boolean filled;
    
};

// Derived class
class Triangle extends GeometricObject
{

double t1,t2,t3,perimeter,p,pd,area;

     Triangle()
   {
   setSide1(1.0);
   setSide2(1.0);
   setSide3(1.0);

   }
    Triangle(double t1,double t2,double t3)
   {
   setSide1(t1);
   setSide2(t2);
   setSide3(t3);

   }

      double getArea()
      {
      p=getPerimeter()/2;
      pd=p*(p-t1)*(p-t2)*(p-t3);
      area=Math.sqrt(pd);
         return (area);
      }
      double getPerimeter()
      {
      t1=getSide1();
      t2=getSide2();
      t3=getSide3();
      perimeter=t1+t2+t3;
      return (t1+t2+t3);
      }
};


class TestTriangle
{
public static void main(String []args)

{

System.out.println("Enter three sides: ");
Scanner sc=new Scanner(System.in);

double side1, side2, side3;

side1=sc.nextDouble();
side2=sc.nextDouble();
side3=sc.nextDouble();
Triangle triangle=new Triangle(side1, side2, side3);

System.out.println("Enter the color: ");

String color;

color=sc.next();

System.out.println("Enter true/false for filled : ");

boolean filled;

filled=sc.nextBoolean();


triangle.setColor(color);

triangle.setFilled(filled);

System.out.println("Area is "+triangle.getArea());

System.out.println("Perimeter is "+triangle.getPerimeter());

System.out.println("Color is " +triangle.getColor());

System.out.println("Filled is "+(triangle.isFilled()));

}
}