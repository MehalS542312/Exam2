/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S542312
 */
public class latebindingpolymorphism {
     public static class solarsystem {
        void print()
        {
            System.out.println("print superclass.");
        }
    }
  
    public static class planets extends solarsystem {
        @Override
        void print()
        {
            System.out.println("print subclass.");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         solarsystem m = new solarsystem();
        solarsystem n = new planets();
        m.print();
        n.print();
    }
    
}
