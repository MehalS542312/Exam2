/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S542312
 */

   public class polymorphism{
   public void food(){
      System.out.println("Animal food");   
   }
}

    class Goat extends polymorphism{
    @Override
    public void food(){
        System.out.println("Grass");
    }
    public static void main(String args[]){
    	polymorphism obj = new Goat();
    	obj.food();
    }
}
