
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author S542312
 */
public class array1d {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // TODO code application logic here
    ArrayList<Integer> list = new ArrayList<>();
  Scanner scan = new Scanner(System.in);
  System.out.print("Enter ten integers: ");
    int[] input = new int[10];
     for (int m = 0; m< 10; m++)
     {
      input[m] = scan.nextInt();
      list.add(input[m]);
     }
  scan.close();
  removeDuplicate(list);
  System.out.print("The Ddistinct integers are: ");
  for (int m = 0; m< list.size(); m++)
  {
   System.out.print(list.get(m) + " ");
  }
}
public static void removeDuplicate(ArrayList<Integer> list)
{
  for (int m = 0; m < list.size(); m++)
  {
   Integer inte = list.get(m);
   List sublist = list.subList(m+ 1, list.size());
   while (sublist.contains(inte))
   {
    sublist.remove(inte);
   }
  }
}
}
