/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S542312
 */


 abstract class Example {
 void fun() { System.out.println("Base fun() called"); }
}
  
class Derived extends Example {
}
  
class Main {
    public static void main(String args[])
    {
        Derived m = new Derived();
        m.fun();
    }
}
