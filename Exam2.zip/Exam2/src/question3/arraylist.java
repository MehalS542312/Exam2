/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author S542312
 */
public class arraylist {
    double amount;
    double rate;
    int time;
     arraylist(){

    }
    /**
     * @param amount
     * @param rate
     * @param time
     */
     public arraylist(double amount, double rate, int time) {
        this.amount = amount;
        this.rate = rate;
        this.time = time;
    }
    @Override
    public String toString() {
        return "Loan{" + "amount=" + amount +", rate=" + rate +", time=" + time +'}';
    }
}
class Circle{
    double x,y,r;

    public Circle(double x, double y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

@Override
public String toString() {
    return "Circle{" + "x=" + x + ", y=" + y + ", r=" + r + '}';
    }
}
    class Main{
    public static void main(String[] args) {
        ArrayList<Object> obt = new ArrayList<>();
        obt.add(new arraylist(120000,8.2,3));
        obt.add(new Date());
        obt.add(new Circle(4,4,8));
        for(Object x : obt){
            System.out.println(x.toString());
        }
    }
}
