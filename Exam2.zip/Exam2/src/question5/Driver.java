/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question5;

/**
 *
 * @author s542312
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person p = new Person("Rahul");
        Student s = new Student("Vinay");
        Employee e = new Employee("Manoj");
        Faculty f = new Faculty("Venky");
        Staff S = new Staff("Kiran");
        System.out.println("Question 5 : Mehal Reddy Mula");
        System.out.println(p.toString());
        System.out.println("**************************");
        System.out.println(s.toString());
        System.out.println("**************************");
        System.out.println(e.toString());
        System.out.println("**************************");
        System.out.println(f.toString());
        System.out.println("**************************");
        System.out.println(S.toString());
        System.out.println("**************************");
    }

}
